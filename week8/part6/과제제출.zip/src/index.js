import App from './App.js'

new App(document.querySelector("body"));