### reference

video library : https://ffmpegwasm.netlify.app/docs/getting-started/usage
gif convert : https://github.com/Tonel/video-editor-wasm-react
video trimming : https://github.com/ifeoma-imoh/Video-Trimming-App-Using-ffmpeg.wasm
range slider : https://dev.to/sandra_lewis/building-a-multi-range-slider-in-react-from-scratch-4dl1
